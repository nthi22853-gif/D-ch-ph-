@echo off
setlocal
set "GRADLE_VERSION=9.6"
set "DIST=%USERPROFILE%\.gradle\wrapper-bootstrap\gradle-%GRADLE_VERSION%"
if not exist "%DIST%\bin\gradle.bat" (
  echo Gradle bootstrap requires curl and tar/unzip on PATH.
  echo Please run this project in GitHub Actions or install Gradle locally.
  exit /b 1
)
call "%DIST%\bin\gradle.bat" %*
