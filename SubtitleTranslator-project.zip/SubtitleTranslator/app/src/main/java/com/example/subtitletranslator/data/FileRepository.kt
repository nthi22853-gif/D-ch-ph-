package com.example.subtitletranslator.data
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
class FileRepository(private val context: Context) {
    suspend fun readBytes(uri: Uri): ByteArray = withContext(Dispatchers.IO) {
        context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Không thể đọc file.")
    }
    suspend fun writeText(uri: Uri, text: String) = withContext(Dispatchers.IO) {
        context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            ?: error("Không thể ghi file.")
    }
    fun name(uri: Uri): String = context.contentResolver.query(
        uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
    )?.use { if (it.moveToFirst()) it.getString(0) else null } ?: (uri.lastPathSegment ?: "file")
    fun size(uri: Uri): Long? = context.contentResolver.query(
        uri, arrayOf(OpenableColumns.SIZE), null, null, null
    )?.use { if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else null }
    fun mime(uri: Uri): String? = context.contentResolver.getType(uri)
}
