package com.example.subtitletranslator.translation
import com.example.subtitletranslator.domain.AppLanguage
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

interface TranslationProvider {
    suspend fun translate(text:String, source:AppLanguage, target:AppLanguage):String
    fun close()
}
class MlKitTranslationProvider:TranslationProvider {
    private var translator:Translator?=null; private var key:String?=null
    override suspend fun translate(text:String, source:AppLanguage, target:AppLanguage):String {
        if(text.isBlank()||source==target)return text
        val sc=source.mlKitCode ?: error("Không thể dịch khi nguồn là Auto Detect.")
        val tc=target.mlKitCode ?: error("Ngôn ngữ đích không hợp lệ.")
        val k="$sc->$tc"
        if(key!=k){ translator?.close(); translator=Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(sc).setTargetLanguage(tc).build()); key=k }
        val t=translator ?: error("Translator unavailable")
        return withContext(Dispatchers.IO){t.translate(text).await()}
    }
    override fun close(){translator?.close();translator=null;key=null}
}
class AutoDetectTranslationProvider:TranslationProvider {
    private val id=LanguageIdentification.getClient()
    private val ml=MlKitTranslationProvider()
    override suspend fun translate(text:String,source:AppLanguage,target:AppLanguage):String {
        if(source!=AppLanguage.AUTO)return ml.translate(text,source,target)
        val code=withContext(Dispatchers.IO){id.identifyLanguage(text).await()}
        val s=when(code){"zh","zh-CN","zh-TW"->AppLanguage.CHINESE;"en"->AppLanguage.ENGLISH;"ja"->AppLanguage.JAPANESE;"ko"->AppLanguage.KOREAN;"vi"->AppLanguage.VIETNAMESE;else->error("Không nhận diện được: $code")}
        return ml.translate(text,s,target)
    }
    override fun close(){id.close();ml.close()}
}
