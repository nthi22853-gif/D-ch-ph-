package com.example.subtitletranslator.ui
import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.subtitletranslator.data.FileRepository
import com.example.subtitletranslator.domain.*
import com.example.subtitletranslator.subtitle.*
import com.example.subtitletranslator.translation.AutoDetectTranslationProvider
import com.example.subtitletranslator.video.readVideoMetadata
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UiState(
    val video:SelectedFile?=null,val subtitle:SelectedFile?=null,val cues:List<SubtitleCue> = emptyList(),
    val source:AppLanguage=AppLanguage.AUTO,val target:AppLanguage=AppLanguage.VIETNAMESE,
    val mode:TranslationMode=TranslationMode.QUALITY,val progress:Float=0f,
    val status:String="Sẵn sàng",val busy:Boolean=false,val error:String?=null,
    val search:String="",val encoding:String?=null
)
class MainViewModel(app:Application):AndroidViewModel(app){
    private val repo=FileRepository(app); private val _state=MutableStateFlow(UiState()); val state=_state.asStateFlow(); private var job:Job?=null
    fun setSource(x:AppLanguage){_state.value=_state.value.copy(source=x)}; fun setTarget(x:AppLanguage){_state.value=_state.value.copy(target=x)}
    fun setMode(x:TranslationMode){_state.value=_state.value.copy(mode=x)}; fun setSearch(x:String){_state.value=_state.value.copy(search=x)}
    fun swapLanguages(){val s=_state.value;if(s.source!=AppLanguage.AUTO)_state.value=s.copy(source=s.target,target=s.source)}
    fun cancel(){job?.cancel();job=null;_state.value=_state.value.copy(busy=false,status="Đã hủy",progress=0f)}
    fun loadVideo(uri:Uri){job=viewModelScope.launch{try{val m=readVideoMetadata(getApplication(),uri);_state.value=_state.value.copy(
        video=SelectedFile(uri,repo.name(uri),repo.size(uri),repo.mime(uri),m.durationMs),status="Đã chọn video",error=null)}catch(e:Exception){fail(e)}}}
    fun loadSubtitle(uri:Uri){job=viewModelScope.launch{try{_state.value=_state.value.copy(busy=true,status="Đang đọc phụ đề...",error=null)
        val d=TextEncodingDetector.decode(repo.readBytes(uri));val f=SubtitleParser.detectFormat(repo.name(uri));val c=SubtitleParser.parse(d.text,f)
        _state.value=_state.value.copy(subtitle=SelectedFile(uri,repo.name(uri),repo.size(uri),repo.mime(uri),subtitleCount=c.size),
            cues=c,encoding=d.charsetName,busy=false,status="Đã đọc ${c.size} subtitle")}catch(e:Exception){fail(e)}}}
    fun translate(){val s=_state.value;if(s.cues.isEmpty()){_state.value=s.copy(error="Hãy chọn file phụ đề.");return}
        if(s.target==AppLanguage.AUTO){_state.value=s.copy(error="Ngôn ngữ đích không được là Auto Detect.");return}
        job=viewModelScope.launch{val p=AutoDetectTranslationProvider();try{_state.value=_state.value.copy(busy=true,progress=0f,error=null,status="Đang dịch...")
            val a=s.cues.toMutableList();for(i in a.indices){ensureActive();a[i]=a[i].copy(translatedText=p.translate(a[i].originalText,s.source,s.target))
                _state.value=_state.value.copy(cues=a.toList(),progress=(i+1).toFloat()/a.size,status="Đã dịch ${i+1} / ${a.size} subtitle")}
            _state.value=_state.value.copy(busy=false,status="Hoàn thành")}catch(e:Exception){fail(e)}finally{p.close()}}
    }
    suspend fun export(uri:Uri,format:SubtitleFormat){val s=_state.value;val original=s.subtitle?.let{runCatching{String(repo.readBytes(it.uri),Charsets.UTF_8)}.getOrNull()}
        repo.writeText(uri,SubtitleExporter.export(s.cues,format,original));_state.value=_state.value.copy(status="Đã xuất file")}
    private fun fail(e:Exception){_state.value=_state.value.copy(busy=false,error=e.message?:"Lỗi không xác định",status="Lỗi")}
}
