package com.example.subtitletranslator.domain
data class SubtitleCue(
    val index: Int, val startMs: Long, val endMs: Long,
    val originalText: String, val translatedText: String? = null,
    val rawPrefix: String? = null
)
enum class SubtitleFormat { SRT, ASS, SSA, VTT, TXT }
enum class TranslationMode { FAST, QUALITY }
enum class AppLanguage(val label: String, val mlKitCode: String?) {
    AUTO("Auto Detect", null), CHINESE("Chinese", "zh"), ENGLISH("English", "en"),
    JAPANESE("Japanese", "ja"), KOREAN("Korean", "ko"), VIETNAMESE("Vietnamese", "vi")
}
data class SelectedFile(
    val uri: android.net.Uri, val name: String, val sizeBytes: Long?, val mimeType: String?,
    val durationMs: Long? = null, val subtitleCount: Int? = null
)
