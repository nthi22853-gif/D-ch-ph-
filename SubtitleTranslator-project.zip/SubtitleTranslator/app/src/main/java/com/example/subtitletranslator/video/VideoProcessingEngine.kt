package com.example.subtitletranslator.video
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class VideoMetadata(val durationMs:Long?,val width:Int?,val height:Int?)
suspend fun readVideoMetadata(context:Context,uri:Uri)=withContext(Dispatchers.IO){
    val r=MediaMetadataRetriever()
    try{r.setDataSource(context,uri);VideoMetadata(
        r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull(),
        r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull(),
        r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull())}
    finally{r.release()}
}
interface VideoProcessingEngine {
    suspend fun hardSubtitle(video:Uri,subtitle:Uri,output:Uri)
    suspend fun softSubtitle(video:Uri,subtitle:Uri,output:Uri)
}
class NativeVideoProcessingEngine:VideoProcessingEngine {
    override suspend fun hardSubtitle(video:Uri,subtitle:Uri,output:Uri)=error(
        "Chưa bật FFmpeg native backend. Hãy xuất SRT/ASS/VTT trước."
    )
    override suspend fun softSubtitle(video:Uri,subtitle:Uri,output:Uri)=error(
        "Soft-sub muxing phụ thuộc container/codec. Hãy xuất subtitle trước."
    )
}
