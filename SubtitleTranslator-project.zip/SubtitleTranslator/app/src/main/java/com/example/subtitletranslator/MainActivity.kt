package com.example.subtitletranslator
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.subtitletranslator.domain.*
import com.example.subtitletranslator.subtitle.SubtitleParser
import com.example.subtitletranslator.ui.MainViewModel
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(vm:MainViewModel=viewModel()){
    val s by vm.state.collectAsState();val scope=rememberCoroutineScope()
    var src by remember{mutableStateOf(false)};var dst by remember{mutableStateOf(false)};var export by remember{mutableStateOf(false)}
    val vp=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(vm::loadVideo)}
    val sp=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(vm::loadSubtitle)}
    val ep=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")){u->if(u!=null)scope.launch{
        vm.export(u,s.subtitle?.let{SubtitleParser.detectFormat(it.name)}?:SubtitleFormat.SRT)}}
    MaterialTheme{Scaffold(topBar={TopAppBar(title={Text("Video Subtitle Translator")})}){pad->LazyColumn(
        Modifier.padding(pad).fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Text("Nhập file",style=MaterialTheme.typography.titleMedium);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Button({vp.launch(arrayOf("video/*"))}){Text("📁 Chọn Video")};OutlinedButton({sp.launch(arrayOf("text/*","application/x-subrip"))}){Text("📄 Chọn Phụ Đề")}}}
        s.video?.let{item{FileCard("Video",it.name,it.sizeBytes,it.durationMs,null)}};s.subtitle?.let{item{FileCard("Phụ đề",it.name,it.sizeBytes,null,it.subtitleCount)}}
        item{Text("Ngôn ngữ",style=MaterialTheme.typography.titleMedium);Lang("Nguồn",s.source,src,{src=it},vm);Text("↓")
            Lang("Đích",s.target,dst,{dst=it},vm);TextButton({vm.swapLanguages()},enabled=s.source!=AppLanguage.AUTO){Text("⇄ Đảo ngôn ngữ")}}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(s.mode==TranslationMode.FAST,{vm.setMode(TranslationMode.FAST)},{Text("Dịch nhanh")})
            FilterChip(s.mode==TranslationMode.QUALITY,{vm.setMode(TranslationMode.QUALITY)},{Text("Dịch chất lượng")})}}
        if(s.cues.isNotEmpty())item{OutlinedTextField(s.search,vm::setSearch,Modifier.fillMaxWidth(),label={Text("Tìm kiếm subtitle")})}
        item{if(s.busy){LinearProgressIndicator({s.progress},Modifier.fillMaxWidth());Text("${(s.progress*100).toInt()}% — ${s.status}");OutlinedButton(vm::cancel){Text("Hủy")}}
            else Button(vm::translate,enabled=s.cues.isNotEmpty(),Modifier.fillMaxWidth()){Text("Dịch phụ đề")}}
        item{Text(s.status);s.encoding?.let{Text("Encoding: $it",style=MaterialTheme.typography.bodySmall)};s.error?.let{Text(it,color=MaterialTheme.colorScheme.error)}}
        if(s.cues.isNotEmpty()){item{Text("Xem trước",style=MaterialTheme.typography.titleMedium)}
            items(s.cues.filter{q->s.search.isBlank()||q.originalText.contains(s.search,true)||q.translatedText.orEmpty().contains(s.search,true)}.take(300),key={it.index}){Cue(it)}
            item{Button({export=true},Modifier.fillMaxWidth()){Text("Xuất phụ đề")}}}
    }}}
    if(export)AlertDialog(onDismissRequest={export=false},title={Text("Định dạng xuất")},text={Column{
        SubtitleFormat.values().forEach{f->TextButton({export=false;ep.launch("subtitle.${f.name.lowercase(Locale.US)}")}){Text(f.name)}}}},
        confirmButton={TextButton({export=false}){Text("Đóng")}})
}
@OptIn(ExperimentalMaterial3Api::class)@Composable fun Lang(label:String,v:AppLanguage,open:Boolean,setOpen:(Boolean)->Unit,vm:MainViewModel){
    ExposedDropdownMenuBox(open,setOpen){OutlinedTextField(v.label,{},readOnly=true,label={Text(label)},modifier=Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(open,{setOpen(false)}){AppLanguage.values().forEach{d->DropdownMenuItem({Text(d.label)},{if(label=="Nguồn")vm.setSource(d)else vm.setTarget(d);setOpen(false)})}}}}
@Composable fun FileCard(t:String,n:String,z:Long?,dur:Long?,count:Int?){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(t);Text(n);z?.let{Text("Dung lượng: ${it/1_000_000.0} MB")};dur?.let{Text("Thời lượng: ${it/60000} phút ${it/1000%60} giây")};count?.let{Text("Subtitle: $it dòng")}}}}
@Composable fun Cue(c:SubtitleCue){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(fmt(c.startMs),style=MaterialTheme.typography.labelMedium);Text(c.originalText);c.translatedText?.let{HorizontalDivider(Modifier.padding(vertical=6.dp));Text(it,style=MaterialTheme.typography.bodyLarge)}}}}
fun fmt(x:Long)="%02d:%02d:%02d".format(x/3600000,(x/60000)%60,(x/1000)%60)
