package com.example.subtitletranslator.subtitle
import com.example.subtitletranslator.domain.*
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.util.Locale

data class DecodedText(val text: String, val charsetName: String)

object TextEncodingDetector {
    private val candidates = listOf(
        StandardCharsets.UTF_8, Charsets.UTF_16LE, Charsets.UTF_16BE,
        charset("GB18030"), charset("GBK"), charset("Big5"),
        charset("Shift_JIS"), charset("EUC-KR")
    )
    fun decode(bytes: ByteArray, preferred: String? = null): DecodedText {
        preferred?.let { return DecodedText(String(bytes, charset(it)), it) }
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte())
            return DecodedText(String(bytes, Charsets.UTF_8).removePrefix("\uFEFF"), "UTF-8 BOM")
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte())
            return DecodedText(String(bytes, Charsets.UTF_16LE).removePrefix("\uFEFF"), "UTF-16LE")
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte())
            return DecodedText(String(bytes, Charsets.UTF_16BE).removePrefix("\uFEFF"), "UTF-16BE")
        for (cs in candidates) try {
            val decoder = cs.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
            return DecodedText(decoder.decode(ByteBuffer.wrap(bytes)).toString(), cs.name())
        } catch (_: CharacterCodingException) {}
        return DecodedText(String(bytes, Charsets.UTF_8), "UTF-8 (fallback)")
    }
}

object SubtitleParser {
    private val srt = Regex("""(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})""")
    private val vtt = Regex("""(\d{2}):(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[.,](\d{3})""")
    fun detectFormat(name: String) = when(name.substringAfterLast('.', "").lowercase(Locale.US)) {
        "srt" -> SubtitleFormat.SRT; "ass" -> SubtitleFormat.ASS; "ssa" -> SubtitleFormat.SSA
        "vtt" -> SubtitleFormat.VTT; "txt" -> SubtitleFormat.TXT; else -> SubtitleFormat.SRT
    }
    fun parse(text: String, format: SubtitleFormat): List<SubtitleCue> = when(format) {
        SubtitleFormat.SRT -> parseSrt(text); SubtitleFormat.VTT -> parseVtt(text)
        SubtitleFormat.ASS, SubtitleFormat.SSA -> parseAss(text)
        SubtitleFormat.TXT -> text.lines().filter(String::isNotBlank).mapIndexed { i, x -> SubtitleCue(i+1,0,0,x) }
    }
    private fun parseSrt(text: String): List<SubtitleCue> {
        return text.replace("\r\n","\n").replace("\r","\n").split(Regex("\n{2,}")).mapNotNull { b ->
            val l=b.lines(); val ti=l.indexOfFirst{srt.containsMatchIn(it)}; if(ti<0)return@mapNotNull null
            val m=srt.find(l[ti]) ?: return@mapNotNull null
            SubtitleCue(l.firstOrNull()?.trim()?.toIntOrNull() ?: ti+1, tm(m.groupValues,1),tm(m.groupValues,5),l.drop(ti+1).joinToString("\n"))
        }
    }
    private fun parseVtt(text: String): List<SubtitleCue> {
        var n=1
        return text.replace("\r\n","\n").replace("\r","\n").split(Regex("\n{2,}")).mapNotNull { b ->
            val l=b.lines(); val ti=l.indexOfFirst{vtt.containsMatchIn(it)}; if(ti<0)return@mapNotNull null
            val m=vtt.find(l[ti]) ?: return@mapNotNull null
            SubtitleCue(n++,tm(m.groupValues,1),tm(m.groupValues,5),l.drop(ti+1).joinToString("\n"))
        }
    }
    private fun parseAss(text: String): List<SubtitleCue> {
        val lines=text.replace("\r\n","\n").replace("\r","\n").lines()
        val fmt=lines.firstOrNull{it.trim().startsWith("Format:",true)}?.substringAfter(":")
            ?.split(",")?.map{it.trim().lowercase()} ?: emptyList()
        val si=fmt.indexOf("start"); val ei=fmt.indexOf("end"); val ti=fmt.indexOf("text")
        var n=1
        return lines.mapNotNull { line ->
            if(!line.trimStart().startsWith("Dialogue:",true))return@mapNotNull null
            val payload=line.substringAfter(":")
            val parts=payload.split(",", limit=if(ti>=0)ti+1 else 10)
            val start=(if(si>=0)parts.getOrNull(si) else parts.getOrNull(1))?.trim()
            val end=(if(ei>=0)parts.getOrNull(ei) else parts.getOrNull(2))?.trim()
            val body=parts.drop(if(ti>=0)ti else 9).joinToString(",")
            val a=assTime(start?:return@mapNotNull null) ?: return@mapNotNull null
            val b=assTime(end?:return@mapNotNull null) ?: return@mapNotNull null
            SubtitleCue(n++,a,b,body,rawPrefix=line.substringBefore(body))
        }
    }
    private fun tm(g: List<String>, o:Int)=((g[o].toLong()*3600+g[o+1].toLong()*60+g[o+2].toLong())*1000)+g[o+3].toLong()
    private fun assTime(x:String):Long? { val p=x.split(":"); if(p.size!=3)return null; val s=p[2].replace(",",".").toDoubleOrNull()?:return null; return ((p[0].toLong()*3600+p[1].toLong()*60)*1000+(s*1000).toLong()) }
}

object SubtitleExporter {
    fun export(cues: List<SubtitleCue>, format: SubtitleFormat, originalAss: String? = null): String = when(format) {
        SubtitleFormat.SRT -> cues.joinToString("\n\n"){"${it.index}\n${srt(it.startMs)} --> ${srt(it.endMs)}\n${it.translatedText ?: it.originalText}"}+"\n"
        SubtitleFormat.VTT -> "WEBVTT\n\n"+cues.joinToString("\n\n"){"${vtt(it.startMs)} --> ${vtt(it.endMs)}\n${it.translatedText ?: it.originalText}"}+"\n"
        SubtitleFormat.TXT -> cues.joinToString("\n"){it.translatedText ?: it.originalText}+"\n"
        SubtitleFormat.ASS, SubtitleFormat.SSA -> ass(cues,originalAss)
    }
    private fun ass(cues:List<SubtitleCue>, original:String?):String {
        val lines=(original?.replace("\r\n","\n")?.replace("\r","\n")?.lines()
            ?: listOf("[Script Info]","ScriptType: v4.00+","","[V4+ Styles]",
                "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
                "Style: Default,Arial,20,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,0,2,10,10,10,1","","[Events]",
                "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text")).toMutableList()
        val it=cues.iterator()
        for(i in lines.indices) if(lines[i].trimStart().startsWith("Dialogue:",true)&&it.hasNext()){
            val c=it.next(); val marker=",,"; val p=lines[i].indexOf(marker)
            if(p>=0) lines[i]=lines[i].substring(0,p+marker.length)+(c.translatedText?:c.originalText)
        }
        return lines.joinToString("\n")+"\n"
    }
    private fun srt(ms:Long):String { val h=ms/3600000; val m=(ms/60000)%60; val s=(ms/1000)%60; val x=ms%1000; return "%02d:%02d:%02d,%03d".format(h,m,s,x) }
    private fun vtt(ms:Long)=srt(ms).replace(',', '.')
}
