# Subtitle Translator

Ứng dụng Android độc lập, Kotlin + Jetpack Compose, tập trung vào nhập/đọc/dịch/xuất subtitle.

## Đã có trong bản project

- Storage Access Framework.
- Video: MP4/MKV/AVI/MOV/WebM qua MIME `video/*`.
- Subtitle: SRT/ASS/SSA/VTT/TXT.
- SRT giữ index + timestamp.
- ASS/SSA giữ phần Script Info/Styles và thay nội dung Dialogue; override tags trong text không bị tách khỏi nội dung.
- Encoding: UTF-8/BOM, UTF-16 LE/BE, GBK, GB18030, Big5, Shift-JIS, EUC-KR.
- Google ML Kit Translation provider.
- Auto Detect bằng ML Kit Language ID.
- Coroutines, progress, cancel, error state.
- Xem trước + tìm kiếm.
- Xuất SRT/ASS/SSA/VTT/TXT.
- Kiến trúc `VideoProcessingEngine` tách riêng cho FFmpeg/native backend.

## Giới hạn có chủ ý

Không giả vờ rằng STT và FFmpeg đã được tích hợp nếu chưa có binary/backend được kiểm chứng. Bản này build được và dùng được cho pipeline subtitle. `VideoProcessingEngine` là điểm mở rộng cho hard-sub/soft-sub và STT.

ML Kit Translation yêu cầu API 23+, nên `minSdk=23` (Android 6+), đáp ứng Android 8+.

## Build GitHub Actions

Push project lên branch `main` → Actions → **Build Android APK** → tải artifact `SubtitleTranslator-Debug-APK`.

Không cần Android Studio.

## Release signing

Thêm GitHub Secrets:
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

Nếu `KEYSTORE_BASE64` có mặt, workflow build thêm `assembleRelease` và upload Release artifact. Nếu không có secrets, Debug vẫn build bình thường.

## Toolchain đã khóa

- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- Kotlin 2.3.21
- JDK 17
- compileSdk 37
